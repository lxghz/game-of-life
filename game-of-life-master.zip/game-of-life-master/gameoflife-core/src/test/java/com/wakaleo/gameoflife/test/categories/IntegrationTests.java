package com.wakaleo.gameoflife.test.categories;

public interface IntegrationTests extends SlowTests {

}
